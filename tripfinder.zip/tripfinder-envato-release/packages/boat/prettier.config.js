module.exports = {
  singleQuote: true,
  plugins: [require('prettier-plugin-tailwindcss')],
};
