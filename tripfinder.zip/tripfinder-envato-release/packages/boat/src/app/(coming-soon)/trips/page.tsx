import ComingSoon from '@/components/ui/coming-soon';

export default function Trips() {
  return (
    <>
      <ComingSoon />
    </>
  );
}
