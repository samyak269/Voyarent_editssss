import ForgotPassword from '@/components/auth/forgot-password';
export default function page() {
  return <ForgotPassword />;
}
