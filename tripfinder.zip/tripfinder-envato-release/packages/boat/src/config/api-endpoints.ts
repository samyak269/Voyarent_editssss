export const API_ENDPOINTS = {
  TOP_DESTINATIONS: '/top-destinations.json',
  BOATS: '',
  TOP_BOATS: '/top-boats.json',
  NEW_BOATS: '',
  TESTIMONIALS: '/testimonial.json',
  LISTING_DETAILS: '',
  RELATED_BOATS: '',
  REVIEWS: '/listing-details.json',
};
