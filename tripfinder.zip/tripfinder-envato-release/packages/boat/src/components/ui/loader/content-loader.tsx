import ContentLoader from 'react-content-loader';

export default ContentLoader;
