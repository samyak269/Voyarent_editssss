export const testimonials = [
  {
    name: 'Charles Patterson',
    description:
      '“OMG! I cannot believe that I have got a brand new landing page after getting this template we are able to use our most used e-commerce for your branding site to make it cool.”',
    location: 'from Duisbarg',
    rating: 4.5,
  },
  {
    name: 'Bojoer',
    description:
      '“I cannot believe we are able to use our most that I have got a brand new landing page after getting this template used e-commerce for your branding site to make it cool. OMG!',
    location: 'from Duisbarg',
    rating: 4,
  },
  {
    name: 'Kay Stenschke',
    description:
      '“This template used e-commerce for your branding site cannot believe we are able to use our most that I have got a brand new landing page after getting. I to make it cool. OMG!”',
    location: 'from Duisbarg',
    rating: 3,
  },
  {
    name: 'Lomm Patt.',
    description:
      '“landing page after this template used e-commerce for your branding site cannot believe we are able to use our most that. OMG! I have got a brand new getting. I to make it cool.”',
    location: 'from Duisbarg',
    rating: 5,
  },
  {
    name: 'Charles Jhon',
    description:
      '“Use our most that I have got a brand this template used e-commerce for your branding site cannot we are able to  new landing page after getting. I believe to make it cool. OMG!”',
    location: 'from Duisbarg',
    rating: 3.5,
  },
  {
    name: 'Adam Osh',
    description:
      '“Your branding site cannot we are able. Use our most that I have got a brand this template used e-commerce. I believe to make it cool. OMG! for to new landing page after getting.',
    location: 'from Duisbarg',
    rating: 5,
  },
  {
    name: 'Jhon Lee',
    description:
      '“A brand this template used e-commerce for your branding. Use our most that I believe to make it cool. OMG!. I have got site cannot we are able to new landing page after getting.”',
    location: 'from Duisbarg',
    rating: 3.5,
  },
];