export const dashboardCardData = [
    {
      id: 'cardone',
      title: 'New Orders',
      order: 157,
      last: 178,
      price: null,
    },
    {
      id: 'cardtwo',
      title: 'New Orders Revenue',
      order: null,
      last: 12,
      price: 1489.59,
    },
    {
      id: 'cardthree',
      title: 'Avg. Order Revenue',
      order: null,
      last: 12,
      price: 789.99,
    },
  ];