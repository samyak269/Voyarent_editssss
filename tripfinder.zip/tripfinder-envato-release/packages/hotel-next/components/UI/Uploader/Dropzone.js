import Dropzone from 'react-dropzone-component';

export default Dropzone;
