import Privacy from 'containers/Privacy/Privacy';

export default function privacy() {
  return <Privacy />;
}
