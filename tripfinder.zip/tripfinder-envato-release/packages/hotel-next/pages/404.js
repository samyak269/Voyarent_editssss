import ErrorPage from 'containers/404/404';

export default function NotFoundPage() {
  return <ErrorPage errorCode={404} />;
}
